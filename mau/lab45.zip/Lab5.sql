-- =====================================================================================
-- HỌ VÀ TÊN: Lê Đỗ Anh Khoa
-- MSSV: QE210269
-- LỚP: SE20D
-- MÔN HỌC: DBI202 - DATABASE SYSTEMS
-- BÀI TẬP: LAB 5 - FUNCTION, PROCEDURE, TRIGGER, VIEW (ABCCompany)
-- =====================================================================================

-- =====================================================================================
-- PHẦN 1: KHỞI TẠO CƠ SỞ DỮ LIỆU VÀ DỮ LIỆU MẪU
-- =====================================================================================
USE master;
GO

IF DB_ID('ABCCompany') IS NOT NULL
BEGIN
    ALTER DATABASE ABCCompany SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE ABCCompany;
END
GO

CREATE DATABASE ABCCompany;
GO

USE ABCCompany;
GO

CREATE TABLE KHACHHANG
(
    MaKH nvarchar(5) NOT NULL PRIMARY KEY,
    TenKH nvarchar(30) NOT NULL,
    DiaChi nvarchar(50),
    DT nvarchar(10),
    Email nvarchar(30)
);
GO

CREATE TABLE VATTU
(
    MaVT nvarchar(5) PRIMARY KEY NOT NULL,
    TenVT nvarchar(30) NOT NULL,
    DVT nvarchar(20),
    GiaMua int CHECK (GiaMua > 0),
    SLTon int CHECK (SLTon >= 0)
);
GO

CREATE TABLE HOADON
(
    MaHD nvarchar(10) PRIMARY KEY NOT NULL,
    Ngay datetime CHECK(Ngay < GETDATE()),
    MaKH nvarchar(5) FOREIGN KEY REFERENCES KHACHHANG(MaKH),
    TongTG int
);
GO

CREATE TABLE CHITIETHOADON
(
    MaHD nvarchar(10) FOREIGN KEY REFERENCES HOADON(MaHD),
    MaVT nvarchar(5) FOREIGN KEY REFERENCES VATTU(MaVT),
    PRIMARY KEY (MaHD, MaVT),
    SL int,
    KhuyenMai int,
    GiaBan int
);
GO

-- Chèn dữ liệu bảng VATTU
INSERT INTO VATTU VALUES('VT01', 'XI MANG', 'BAO', 50000, 5000);
INSERT INTO VATTU VALUES('VT02', 'CAT', 'KHOI', 45000, 50000);
INSERT INTO VATTU VALUES('VT03', 'GACH ONG', 'VIEN', 120, 800000);
INSERT INTO VATTU VALUES('VT04', 'GACH THE', 'VIEN', 110, 800000);
INSERT INTO VATTU VALUES('VT05', 'DA LON', 'KHOI', 25000, 100000);
INSERT INTO VATTU VALUES('VT06', 'DA NHO', 'KHOI', 33000, 100000);
GO

-- Chèn dữ liệu bảng KHACHHANG
INSERT INTO KHACHHANG VALUES('KH01', 'NGUYEN THI BE', 'TAN BINH', '8457895', 'bnt@yahoo.com');
INSERT INTO KHACHHANG VALUES('KH02', 'LE HOANG NAM', 'BINH CHANH', '9878987', 'namlehoang @abc.com.vn');
INSERT INTO KHACHHANG VALUES('KH03', 'TRAN THI CHIEU', 'TAN BINH', '8457895', NULL);
INSERT INTO KHACHHANG VALUES('KH04', 'MAI THI QUE ANH', 'BINH CHANH', NULL, NULL);
INSERT INTO KHACHHANG VALUES('KH05', 'LE VAN SANG', 'QUAN 10', NULL, 'sanglv@hcm.vnn.vn');
INSERT INTO KHACHHANG VALUES('KH06', 'TRAN HOANG KHAI', 'TAN BINH', '8457897', NULL);
GO

-- Chèn dữ liệu bảng HOADON
INSERT INTO HOADON([MaHD], [Ngay], [MaKH]) VALUES('HD001', '2000-05-12', 'KH01');
INSERT INTO HOADON([MaHD], [Ngay], [MaKH]) VALUES('HD002', '2000-05-25', 'KH02');
INSERT INTO HOADON([MaHD], [Ngay], [MaKH]) VALUES('HD003', '2000-05-25', 'KH01');
INSERT INTO HOADON([MaHD], [Ngay], [MaKH]) VALUES('HD004', '2000-05-25', 'KH04');
INSERT INTO HOADON([MaHD], [Ngay], [MaKH]) VALUES('HD005', '2000-05-26', 'KH04');
INSERT INTO HOADON([MaHD], [Ngay], [MaKH]) VALUES('HD006', '2000-05-02', 'KH03');
INSERT INTO HOADON([MaHD], [Ngay], [MaKH]) VALUES('HD007', '2000-06-22', 'KH04');
INSERT INTO HOADON([MaHD], [Ngay], [MaKH]) VALUES('HD008', '2000-06-25', 'KH03');
INSERT INTO HOADON([MaHD], [Ngay], [MaKH]) VALUES('HD009', '2000-08-15', 'KH04');
INSERT INTO HOADON([MaHD], [Ngay], [MaKH]) VALUES('HD010', '2000-08-30', 'KH01');
GO

-- Chèn dữ liệu bảng CHITIETHOADON
INSERT INTO CHITIETHOADON([MaHD], [MaVT], [SL], [GiaBan]) VALUES('HD001', 'VT01', 5, 52000);
INSERT INTO CHITIETHOADON([MaHD], [MaVT], [SL], [GiaBan]) VALUES('HD001', 'VT05', 10, 30000);
INSERT INTO CHITIETHOADON([MaHD], [MaVT], [SL], [GiaBan]) VALUES('HD002', 'VT03', 10000, 150);
INSERT INTO CHITIETHOADON([MaHD], [MaVT], [SL], [GiaBan]) VALUES('HD003', 'VT02', 20, 55000);
INSERT INTO CHITIETHOADON([MaHD], [MaVT], [SL], [GiaBan]) VALUES('HD004', 'VT03', 50000, 150);
INSERT INTO CHITIETHOADON([MaHD], [MaVT], [SL], [GiaBan]) VALUES('HD004', 'VT04', 20000, 120);
INSERT INTO CHITIETHOADON([MaHD], [MaVT], [SL], [GiaBan]) VALUES('HD005', 'VT05', 10, 30000);
INSERT INTO CHITIETHOADON([MaHD], [MaVT], [SL], [GiaBan]) VALUES('HD006', 'VT04', 10000, 120);
INSERT INTO CHITIETHOADON([MaHD], [MaVT], [SL], [GiaBan]) VALUES('HD007', 'VT04', 20000, 125);
INSERT INTO CHITIETHOADON([MaHD], [MaVT], [SL], [GiaBan]) VALUES('HD008', 'VT01', 100, 55000);
INSERT INTO CHITIETHOADON([MaHD], [MaVT], [SL], [GiaBan]) VALUES('HD009', 'VT02', 25, 48000);
INSERT INTO CHITIETHOADON([MaHD], [MaVT], [SL], [GiaBan]) VALUES('HD010', 'VT01', 25, 57000);
GO


-- =====================================================================================
-- PHẦN 2: THỰC HIỆN CÁC YÊU CẦU LAB 5
-- =====================================================================================

-- -------------------------------------------------------------------------------------
-- 1. Write function name: StudenID_ Func1 with parameter @mavt,
--    return the sum of sl*giaban corresponding.
-- -------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.QE210269_Func1', 'FN') IS NOT NULL
    DROP FUNCTION dbo.QE210269_Func1;
GO

CREATE FUNCTION QE210269_Func1 (@mavt nvarchar(5))
RETURNS bigint
AS
BEGIN
    DECLARE @TongTien bigint;
    SELECT @TongTien = ISNULL(SUM(CAST(SL AS bigint) * GiaBan), 0)
    FROM CHITIETHOADON
    WHERE MaVT = @mavt;

    RETURN @TongTien;
END;
GO

-- Kiểm tra Function 1:
-- SELECT dbo.QE210269_Func1('VT01') AS TongTien_VT01;
GO


-- -------------------------------------------------------------------------------------
-- 2. Write function to return a total of the HoaDon (@MahD is a parameter)
-- -------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.QE210269_Func2', 'FN') IS NOT NULL
    DROP FUNCTION dbo.QE210269_Func2;
GO

CREATE FUNCTION QE210269_Func2 (@MaHD nvarchar(10))
RETURNS bigint
AS
BEGIN
    DECLARE @TongTienHD bigint;
    SELECT @TongTienHD = ISNULL(SUM(CAST(SL AS bigint) * GiaBan), 0)
    FROM CHITIETHOADON
    WHERE MaHD = @MaHD;

    RETURN @TongTienHD;
END;
GO

-- Kiểm tra Function 2:
-- SELECT dbo.QE210269_Func2('HD001') AS TongTien_HD001;
GO


-- -------------------------------------------------------------------------------------
-- 3. Write procedure name: StudenId _Proc1, parameter @makh, @diachi.
--    This procedure help user update @diachi corresponding @makh.
-- -------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.QE210269_Proc1', 'P') IS NOT NULL
    DROP PROCEDURE dbo.QE210269_Proc1;
GO

CREATE PROCEDURE QE210269_Proc1
    @makh nvarchar(5),
    @diachi nvarchar(50)
AS
BEGIN
    SET NOCOUNT ON;
    
    IF NOT EXISTS (SELECT 1 FROM KHACHHANG WHERE MaKH = @makh)
    BEGIN
        RAISERROR(N'Khách hàng với mã %s không tồn tại!', 16, 1, @makh);
        RETURN;
    END

    UPDATE KHACHHANG
    SET DiaChi = @diachi
    WHERE MaKH = @makh;
END;
GO

-- Kiểm tra Procedure 1:
-- EXEC dbo.QE210269_Proc1 @makh = 'KH01', @diachi = N'QUẬN 1, TP. HCM';
-- SELECT * FROM KHACHHANG WHERE MaKH = 'KH01';
GO


-- -------------------------------------------------------------------------------------
-- 4. Write procedure to add an item into Hoadon
-- (Thêm một mặt hàng vào chi tiết hoá đơn: kiểm tra tồn tại và cộng dồn số lượng nếu đã có)
-- -------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.QE210269_Proc_AddItem', 'P') IS NOT NULL
    DROP PROCEDURE dbo.QE210269_Proc_AddItem;
GO

CREATE PROCEDURE QE210269_Proc_AddItem
    @MaHD nvarchar(10),
    @MaVT nvarchar(5),
    @SL int,
    @KhuyenMai int = 0,
    @GiaBan int = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra hoá đơn có tồn tại không
    IF NOT EXISTS (SELECT 1 FROM HOADON WHERE MaHD = @MaHD)
    BEGIN
        RAISERROR(N'Mã hoá đơn %s không tồn tại trong hệ thống!', 16, 1, @MaHD);
        RETURN;
    END

    -- Kiểm tra vật tư có tồn tại không
    IF NOT EXISTS (SELECT 1 FROM VATTU WHERE MaVT = @MaVT)
    BEGIN
        RAISERROR(N'Mã vật tư %s không tồn tại trong hệ thống!', 16, 1, @MaVT);
        RETURN;
    END

    -- Nếu chưa nhập đơn giá bán, tự động lấy giá mua của vật tư làm giá bán mặc định
    IF @GiaBan IS NULL
    BEGIN
        SELECT @GiaBan = GiaMua FROM VATTU WHERE MaVT = @MaVT;
    END

    -- Nếu mặt hàng đã tồn tại trong hoá đơn thì cập nhật số lượng, ngược lại thì thêm mới
    IF EXISTS (SELECT 1 FROM CHITIETHOADON WHERE MaHD = @MaHD AND MaVT = @MaVT)
    BEGIN
        UPDATE CHITIETHOADON
        SET SL = SL + @SL,
            GiaBan = @GiaBan,
            KhuyenMai = @KhuyenMai
        WHERE MaHD = @MaHD AND MaVT = @MaVT;
    END
    ELSE
    BEGIN
        INSERT INTO CHITIETHOADON (MaHD, MaVT, SL, KhuyenMai, GiaBan)
        VALUES (@MaHD, @MaVT, @SL, @KhuyenMai, @GiaBan);
    END
END;
GO

-- Kiểm tra Procedure thêm item vào hoá đơn:
-- EXEC dbo.QE210269_Proc_AddItem @MaHD = 'HD001', @MaVT = 'VT02', @SL = 5, @KhuyenMai = 0, @GiaBan = 50000;
-- SELECT * FROM CHITIETHOADON WHERE MaHD = 'HD001';
GO


-- -------------------------------------------------------------------------------------
-- 5. Write trigger name: StudenId_ Trig1 on table Chitiethoadon,
--    when user insert data into Chitiethoadon, the trigger will update the Tongtien in HoaDon
--    (student should add Tongtien column into Hoadon, tongtien=sum(sl*giaban)).
-- -------------------------------------------------------------------------------------

-- Bước 5.1: Thêm cột Tongtien vào bảng HOADON nếu chưa có
IF NOT EXISTS (
    SELECT 1 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'HOADON' AND COLUMN_NAME = 'Tongtien'
)
BEGIN
    ALTER TABLE HOADON ADD Tongtien bigint;
END;
GO

-- Cập nhật giá trị ban đầu cho cột Tongtien của các hoá đơn hiện có
UPDATE h
SET Tongtien = ISNULL((
    SELECT SUM(CAST(ct.SL AS bigint) * ct.GiaBan)
    FROM CHITIETHOADON ct
    WHERE ct.MaHD = h.MaHD
), 0)
FROM HOADON h;
GO

-- Bước 5.2: Tạo trigger StudenId_Trig1
IF OBJECT_ID('dbo.QE210269_Trig1', 'TR') IS NOT NULL
    DROP TRIGGER dbo.QE210269_Trig1;
GO

CREATE TRIGGER QE210269_Trig1
ON CHITIETHOADON
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    -- Tự động tính lại Tongtien cho tất cả các hoá đơn bị tác động (thêm, sửa, hoặc xoá)
    UPDATE h
    SET Tongtien = ISNULL((
        SELECT SUM(CAST(ct.SL AS bigint) * ct.GiaBan)
        FROM CHITIETHOADON ct
        WHERE ct.MaHD = h.MaHD
    ), 0)
    FROM HOADON h
    WHERE h.MaHD IN (
        SELECT DISTINCT MaHD FROM inserted
        UNION
        SELECT DISTINCT MaHD FROM deleted
    );
END;
GO

-- Kiểm tra Trigger:
-- SELECT MaHD, Tongtien FROM HOADON WHERE MaHD = 'HD001';
-- INSERT INTO CHITIETHOADON (MaHD, MaVT, SL, GiaBan) VALUES ('HD001', 'VT06', 10, 35000);
-- SELECT MaHD, Tongtien FROM HOADON WHERE MaHD = 'HD001';
-- DELETE FROM CHITIETHOADON WHERE MaHD = 'HD001' AND MaVT = 'VT06';
-- SELECT MaHD, Tongtien FROM HOADON WHERE MaHD = 'HD001';
GO


-- -------------------------------------------------------------------------------------
-- 6. Write view name: StudentID_View1 to extract list of customers who bought ‘Gach Ong’
-- -------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.QE210269_View1', 'V') IS NOT NULL
    DROP VIEW dbo.QE210269_View1;
GO

CREATE VIEW QE210269_View1
AS
SELECT DISTINCT 
    kh.MaKH AS [Mã khách hàng],
    kh.TenKH AS [Tên khách hàng],
    kh.DiaChi AS [Địa chỉ],
    kh.DT AS [Điện thoại],
    kh.Email AS [Email]
FROM KHACHHANG kh
JOIN HOADON hd ON kh.MaKH = hd.MaKH
JOIN CHITIETHOADON ct ON hd.MaHD = ct.MaHD
JOIN VATTU vt ON ct.MaVT = vt.MaVT
WHERE vt.TenVT = 'GACH ONG';
GO

-- Kiểm tra View:
-- SELECT * FROM dbo.QE210269_View1;
GO
