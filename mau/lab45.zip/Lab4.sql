-- =====================================================================================
-- HỌ VÀ TÊN: Lê Đỗ Anh Khoa
-- MSSV: QE210269
-- LỚP: SE20D
-- MÔN HỌC: DBI202 - DATABASE SYSTEMS
-- BÀI TẬP: LAB 4 - SQL QUERIES (FUH_COMPANY / CompanyDB)
-- =====================================================================================

USE CompanyDB;
-- (Nếu bạn restore database với tên khác như FUH_COMPANY, vui lòng đổi tên ở dòng USE trên)
GO

-- -------------------------------------------------------------------------------------
-- Câu 1: Cho biết ai đang quản lý phòng ban có tên: Phòng Nghiên cứu và phát triển.
-- Thông tin yêu cầu: mã số, họ tên nhân viên, mã số phòng ban, tên phòng ban
-- -------------------------------------------------------------------------------------
SELECT 
    e.empSSN AS [Mã số nhân viên],
    e.empName AS [Họ tên nhân viên],
    d.depNum AS [Mã số phòng ban],
    d.depName AS [Tên phòng ban]
FROM tblDepartment d
JOIN tblEmployee e ON d.mgrSSN = e.empSSN
WHERE d.depName = N'Phòng Nghiên cứu và phát triển';
GO

-- -------------------------------------------------------------------------------------
-- Câu 2: Cho phòng ban có tên: Phòng Nghiên cứu và phát triển hiện đang quản lý dự án nào.
-- Thông tin yêu cầu: mã số dự án, tên dự án, tên phòng ban quản lý
-- -------------------------------------------------------------------------------------
SELECT 
    p.proNum AS [Mã số dự án],
    p.proName AS [Tên dự án],
    d.depName AS [Tên phòng ban quản lý]
FROM tblProject p
JOIN tblDepartment d ON p.depNum = d.depNum
WHERE d.depName = N'Phòng Nghiên cứu và phát triển';
GO

-- -------------------------------------------------------------------------------------
-- Câu 3: Cho biết dự án có tên ProjectB hiện đang được quản lý bởi phòng ban nào.
-- Thông tin yêu cầu: mã số dự án, tên dự án, tên phòng ban quản lý
-- -------------------------------------------------------------------------------------
SELECT 
    p.proNum AS [Mã số dự án],
    p.proName AS [Tên dự án],
    d.depName AS [Tên phòng ban quản lý]
FROM tblProject p
JOIN tblDepartment d ON p.depNum = d.depNum
WHERE p.proName = 'ProjectB';
GO

-- -------------------------------------------------------------------------------------
-- Câu 4: Cho biết những nhân viên nào đang bị giám sát bởi nhân viên có tên Mai Duy An.
-- Thông tin yêu cầu: mã số nhân viên, họ tên nhân viên
-- -------------------------------------------------------------------------------------
SELECT 
    e.empSSN AS [Mã số nhân viên],
    e.empName AS [Họ tên nhân viên]
FROM tblEmployee e
JOIN tblEmployee s ON e.supervisorSSN = s.empSSN
WHERE s.empName = N'Mai Duy An';
GO

-- -------------------------------------------------------------------------------------
-- Câu 5: Cho biết ai hiện đang giám sát những nhân viên có tên Mai Duy An.
-- Thông tin yêu cầu: mã số nhân viên, họ tên nhân viên giám sát.
-- -------------------------------------------------------------------------------------
SELECT 
    s.empSSN AS [Mã số nhân viên giám sát],
    s.empName AS [Họ tên nhân viên giám sát]
FROM tblEmployee e
JOIN tblEmployee s ON e.supervisorSSN = s.empSSN
WHERE e.empName = N'Mai Duy An';
GO

-- -------------------------------------------------------------------------------------
-- Câu 6: Cho biết dự án có tên ProjectA hiện đang làm việc ở đâu.
-- Thông tin yêu cầu: mã số, tên vị trí làm việc.
-- -------------------------------------------------------------------------------------
SELECT 
    l.locNum AS [Mã vị trí làm việc],
    l.locName AS [Tên vị trí làm việc]
FROM tblProject p
JOIN tblLocation l ON p.locNum = l.locNum
WHERE p.proName = 'ProjectA';
GO

-- -------------------------------------------------------------------------------------
-- Câu 7: Cho biết vị trí làm việc có tên Tp. HCM hiện đang là chỗ làm việc của những dự án nào.
-- Thông tin yêu cầu: mã số, tên dự án
-- -------------------------------------------------------------------------------------
SELECT 
    p.proNum AS [Mã số dự án],
    p.proName AS [Tên dự án]
FROM tblProject p
JOIN tblLocation l ON p.locNum = l.locNum
WHERE l.locName LIKE N'%Hồ Chí Minh%' OR l.locName LIKE N'%HCM%';
GO

-- -------------------------------------------------------------------------------------
-- Câu 8: Cho biết những người phụ thuộc trên 18 tuổi.
-- Thông tin yêu cầu: tên, ngày tháng năm sinh của người phụ thuộc, tên nhân viên phụ thuộc vào.
-- -------------------------------------------------------------------------------------
SELECT 
    d.depName AS [Tên người phụ thuộc],
    d.depBirthdate AS [Ngày sinh người phụ thuộc],
    e.empName AS [Tên nhân viên phụ thuộc vào]
FROM tblDependent d
JOIN tblEmployee e ON d.empSSN = e.empSSN
WHERE (DATEDIFF(YEAR, d.depBirthdate, GETDATE()) - 
       (CASE WHEN DATEADD(YEAR, DATEDIFF(YEAR, d.depBirthdate, GETDATE()), d.depBirthdate) > GETDATE() THEN 1 ELSE 0 END)) > 18;
GO

-- -------------------------------------------------------------------------------------
-- Câu 9: Cho biết những người phụ thuộc là nam giới.
-- Thông tin yêu cầu: tên, ngày tháng năm sinh của người phụ thuộc, tên nhân viên phụ thuộc vào
-- -------------------------------------------------------------------------------------
SELECT 
    d.depName AS [Tên người phụ thuộc],
    d.depBirthdate AS [Ngày sinh người phụ thuộc],
    e.empName AS [Tên nhân viên phụ thuộc vào]
FROM tblDependent d
JOIN tblEmployee e ON d.empSSN = e.empSSN
WHERE d.depSex = 'M';
GO

-- -------------------------------------------------------------------------------------
-- Câu 10: Cho biết những nơi làm việc của phòng ban có tên : Phòng Nghiên cứu và phát triển.
-- Thông tin yêu cầu: mã phòng ban, tên phòng ban, tên nơi làm việc.
-- -------------------------------------------------------------------------------------
SELECT 
    d.depNum AS [Mã phòng ban],
    d.depName AS [Tên phòng ban],
    l.locName AS [Tên nơi làm việc]
FROM tblDepartment d
JOIN tblDepLocation dl ON d.depNum = dl.depNum
JOIN tblLocation l ON dl.locNum = l.locNum
WHERE d.depName = N'Phòng Nghiên cứu và phát triển';
GO

-- -------------------------------------------------------------------------------------
-- Câu 11: Cho biết các dự án làm việc tại Tp. HCM.
-- Thông tin yêu cầu: mã dự án, tên dự án, tên phòng ban chịu trách nhiệm dự án.
-- -------------------------------------------------------------------------------------
SELECT 
    p.proNum AS [Mã dự án],
    p.proName AS [Tên dự án],
    d.depName AS [Tên phòng ban chịu trách nhiệm dự án]
FROM tblProject p
JOIN tblDepartment d ON p.depNum = d.depNum
JOIN tblLocation l ON p.locNum = l.locNum
WHERE l.locName LIKE N'%Hồ Chí Minh%' OR l.locName LIKE N'%HCM%';
GO

-- -------------------------------------------------------------------------------------
-- Câu 12: Cho biết những người phụ thuộc là nữ giới, của nhân viên thuộc phòng ban có tên: Phòng Nghiên cứu và phát triển.
-- Thông tin yêu cầu: tên nhân viên, tên người phụ thuộc, mối liên hệ giữa người phụ thuộc với nhân viên
-- -------------------------------------------------------------------------------------
SELECT 
    e.empName AS [Tên nhân viên],
    d.depName AS [Tên người phụ thuộc],
    d.depRelationship AS [Mối liên hệ]
FROM tblDependent d
JOIN tblEmployee e ON d.empSSN = e.empSSN
JOIN tblDepartment dp ON e.depNum = dp.depNum
WHERE d.depSex = 'F' 
  AND dp.depName = N'Phòng Nghiên cứu và phát triển';
GO

-- -------------------------------------------------------------------------------------
-- Câu 13: Cho biết những người phụ thuộc trên 18 tuổi, của nhân viên thuộc phòng ban có tên: Phòng Nghiên cứu và phát triển.
-- Thông tin yêu cầu: tên nhân viên, tên người phụ thuộc, mối liên hệ giữa người phụ thuộc với nhân viên
-- -------------------------------------------------------------------------------------
SELECT 
    e.empName AS [Tên nhân viên],
    d.depName AS [Tên người phụ thuộc],
    d.depRelationship AS [Mối liên hệ]
FROM tblDependent d
JOIN tblEmployee e ON d.empSSN = e.empSSN
JOIN tblDepartment dp ON e.depNum = dp.depNum
WHERE dp.depName = N'Phòng Nghiên cứu và phát triển'
  AND (DATEDIFF(YEAR, d.depBirthdate, GETDATE()) - 
       (CASE WHEN DATEADD(YEAR, DATEDIFF(YEAR, d.depBirthdate, GETDATE()), d.depBirthdate) > GETDATE() THEN 1 ELSE 0 END)) > 18;
GO

-- -------------------------------------------------------------------------------------
-- Câu 14: Cho biết số lượng người phụ thuộc theo giới tính.
-- Thông tin yêu cầu: giới tính, số lượng người phụ thuộc
-- -------------------------------------------------------------------------------------
SELECT 
    depSex AS [Giới tính],
    COUNT(*) AS [Số lượng người phụ thuộc]
FROM tblDependent
GROUP BY depSex;
GO

-- -------------------------------------------------------------------------------------
-- Câu 15: Cho biết số lượng người phụ thuộc theo mối liên hệ với nhân viên.
-- Thông tin yêu cầu: mối liên hệ, số lượng người phụ thuộc
-- -------------------------------------------------------------------------------------
SELECT 
    depRelationship AS [Mối liên hệ],
    COUNT(*) AS [Số lượng người phụ thuộc]
FROM tblDependent
GROUP BY depRelationship;
GO

-- -------------------------------------------------------------------------------------
-- Câu 16: Cho biết số lượng người phụ thuộc theo mỗi phòng ban.
-- Thông tin yêu cầu: mã phòng ban, tên phòng ban, số lượng người phụ thuộc
-- -------------------------------------------------------------------------------------
SELECT 
    d.depNum AS [Mã phòng ban],
    d.depName AS [Tên phòng ban],
    COUNT(dep.depName) AS [Số lượng người phụ thuộc]
FROM tblDepartment d
LEFT JOIN tblEmployee e ON d.depNum = e.depNum
LEFT JOIN tblDependent dep ON e.empSSN = dep.empSSN
GROUP BY d.depNum, d.depName;
GO

-- -------------------------------------------------------------------------------------
-- Câu 17: Cho biết phòng ban nào có số lượng người phụ thuộc là ít nhất.
-- Thông tin yêu cầu: mã phòng ban, tên phòng ban, số lượng người phụ thuộc
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    d.depNum AS [Mã phòng ban],
    d.depName AS [Tên phòng ban],
    COUNT(dep.depName) AS [Số lượng người phụ thuộc]
FROM tblDepartment d
LEFT JOIN tblEmployee e ON d.depNum = e.depNum
LEFT JOIN tblDependent dep ON e.empSSN = dep.empSSN
GROUP BY d.depNum, d.depName
ORDER BY [Số lượng người phụ thuộc] ASC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 18: Cho biết phòng ban nào có số lượng người phụ thuộc là nhiều nhất.
-- Thông tin yêu cầu: mã phòng ban, tên phòng ban, số lượng người phụ thuộc
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    d.depNum AS [Mã phòng ban],
    d.depName AS [Tên phòng ban],
    COUNT(dep.depName) AS [Số lượng người phụ thuộc]
FROM tblDepartment d
LEFT JOIN tblEmployee e ON d.depNum = e.depNum
LEFT JOIN tblDependent dep ON e.empSSN = dep.empSSN
GROUP BY d.depNum, d.depName
ORDER BY [Số lượng người phụ thuộc] DESC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 19: Cho biết tổng số giờ tham gia dự án của mỗi nhân viên.
-- Thông tin yêu cầu: mã nhân viên, tên nhân viên, tên phòng ban của nhân viên
-- -------------------------------------------------------------------------------------
SELECT 
    e.empSSN AS [Mã nhân viên],
    e.empName AS [Tên nhân viên],
    d.depName AS [Tên phòng ban],
    ISNULL(SUM(w.workHours), 0) AS [Tổng số giờ]
FROM tblEmployee e
JOIN tblDepartment d ON e.depNum = d.depNum
JOIN tblWorksOn w ON e.empSSN = w.empSSN
GROUP BY e.empSSN, e.empName, d.depName;
GO

-- -------------------------------------------------------------------------------------
-- Câu 20: Cho biết tổng số giờ làm dự án của mỗi phòng ban.
-- Thông tin yêu cầu: mã phòng ban, tên phòng ban, tổng số giờ
-- -------------------------------------------------------------------------------------
SELECT 
    d.depNum AS [Mã phòng ban],
    d.depName AS [Tên phòng ban],
    ISNULL(SUM(w.workHours), 0) AS [Tổng số giờ]
FROM tblDepartment d
LEFT JOIN tblEmployee e ON d.depNum = e.depNum
LEFT JOIN tblWorksOn w ON e.empSSN = w.empSSN
GROUP BY d.depNum, d.depName;
GO

-- -------------------------------------------------------------------------------------
-- Câu 21: Cho biết nhân viên nào có số giờ tham gia dự án là ít nhất.
-- Thông tin yêu cầu: mã nhân viên, tên nhân viên, tổng số giờ tham gia dự án
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    e.empSSN AS [Mã nhân viên],
    e.empName AS [Tên nhân viên],
    SUM(w.workHours) AS [Tổng số giờ tham gia dự án]
FROM tblEmployee e
JOIN tblWorksOn w ON e.empSSN = w.empSSN
GROUP BY e.empSSN, e.empName
ORDER BY [Tổng số giờ tham gia dự án] ASC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 22: Cho biết nhân viên nào có số giờ tham gia dự án là nhiều nhất.
-- Thông tin yêu cầu: mã nhân viên, tên nhân viên, tổng số giờ tham gia dự án
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    e.empSSN AS [Mã nhân viên],
    e.empName AS [Tên nhân viên],
    SUM(w.workHours) AS [Tổng số giờ tham gia dự án]
FROM tblEmployee e
JOIN tblWorksOn w ON e.empSSN = w.empSSN
GROUP BY e.empSSN, e.empName
ORDER BY [Tổng số giờ tham gia dự án] DESC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 23: Cho biết những nhân viên nào lần đầu tiên tham gia dự án.
-- (Nhân viên chỉ tham gia đúng 1 dự án)
-- Thông tin yêu cầu: mã nhân viên, tên nhân viên, tên phòng ban của nhân viên
-- -------------------------------------------------------------------------------------
SELECT 
    e.empSSN AS [Mã nhân viên],
    e.empName AS [Tên nhân viên],
    d.depName AS [Tên phòng ban]
FROM tblEmployee e
JOIN tblDepartment d ON e.depNum = d.depNum
JOIN tblWorksOn w ON e.empSSN = w.empSSN
GROUP BY e.empSSN, e.empName, d.depName
HAVING COUNT(w.proNum) = 1;
GO

-- -------------------------------------------------------------------------------------
-- Câu 24: Cho biết những nhân viên nào lần thứ hai tham gia dự án.
-- (Nhân viên tham gia đúng 2 dự án)
-- Thông tin yêu cầu: mã nhân viên, tên nhân viên, tên phòng ban của nhân viên
-- -------------------------------------------------------------------------------------
SELECT 
    e.empSSN AS [Mã nhân viên],
    e.empName AS [Tên nhân viên],
    d.depName AS [Tên phòng ban]
FROM tblEmployee e
JOIN tblDepartment d ON e.depNum = d.depNum
JOIN tblWorksOn w ON e.empSSN = w.empSSN
GROUP BY e.empSSN, e.empName, d.depName
HAVING COUNT(w.proNum) = 2;
GO

-- -------------------------------------------------------------------------------------
-- Câu 25: Cho biết những nhân viên nào tham gia tối thiểu hai dự án.
-- Thông tin yêu cầu: mã nhân viên, tên nhân viên, tên phòng ban của nhân viên
-- -------------------------------------------------------------------------------------
SELECT 
    e.empSSN AS [Mã nhân viên],
    e.empName AS [Tên nhân viên],
    d.depName AS [Tên phòng ban]
FROM tblEmployee e
JOIN tblDepartment d ON e.depNum = d.depNum
JOIN tblWorksOn w ON e.empSSN = w.empSSN
GROUP BY e.empSSN, e.empName, d.depName
HAVING COUNT(w.proNum) >= 2;
GO

-- -------------------------------------------------------------------------------------
-- Câu 26: Cho biết số lượng thành viên của mỗi dự án.
-- Thông tin yêu cầu: mã dự án, tên dự án, số lượng thành viên
-- -------------------------------------------------------------------------------------
SELECT 
    p.proNum AS [Mã dự án],
    p.proName AS [Tên dự án],
    COUNT(w.empSSN) AS [Số lượng thành viên]
FROM tblProject p
LEFT JOIN tblWorksOn w ON p.proNum = w.proNum
GROUP BY p.proNum, p.proName;
GO

-- -------------------------------------------------------------------------------------
-- Câu 27: Cho biết tổng số giờ làm của mỗi dự án.
-- Thông tin yêu cầu: mã dự án, tên dự án, tổng số giờ làm
-- -------------------------------------------------------------------------------------
SELECT 
    p.proNum AS [Mã dự án],
    p.proName AS [Tên dự án],
    ISNULL(SUM(w.workHours), 0) AS [Tổng số giờ làm]
FROM tblProject p
LEFT JOIN tblWorksOn w ON p.proNum = w.proNum
GROUP BY p.proNum, p.proName;
GO

-- -------------------------------------------------------------------------------------
-- Câu 28: Cho biết dự án nào có số lượng thành viên là ít nhất.
-- Thông tin yêu cầu: mã dự án, tên dự án, số lượng thành viên
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    p.proNum AS [Mã dự án],
    p.proName AS [Tên dự án],
    COUNT(w.empSSN) AS [Số lượng thành viên]
FROM tblProject p
LEFT JOIN tblWorksOn w ON p.proNum = w.proNum
GROUP BY p.proNum, p.proName
ORDER BY [Số lượng thành viên] ASC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 29: Cho biết dự án nào có số lượng thành viên là nhiều nhất.
-- Thông tin yêu cầu: mã dự án, tên dự án, số lượng thành viên
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    p.proNum AS [Mã dự án],
    p.proName AS [Tên dự án],
    COUNT(w.empSSN) AS [Số lượng thành viên]
FROM tblProject p
LEFT JOIN tblWorksOn w ON p.proNum = w.proNum
GROUP BY p.proNum, p.proName
ORDER BY [Số lượng thành viên] DESC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 30: Cho biết dự án nào có tổng số giờ làm là ít nhất.
-- Thông tin yêu cầu: mã dự án, tên dự án, tổng số giờ làm
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    p.proNum AS [Mã dự án],
    p.proName AS [Tên dự án],
    ISNULL(SUM(w.workHours), 0) AS [Tổng số giờ làm]
FROM tblProject p
LEFT JOIN tblWorksOn w ON p.proNum = w.proNum
GROUP BY p.proNum, p.proName
ORDER BY [Tổng số giờ làm] ASC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 31: Cho biết dự án nào có tổng số giờ làm là nhiều nhất.
-- Thông tin yêu cầu: mã dự án, tên dự án, tổng số giờ làm
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    p.proNum AS [Mã dự án],
    p.proName AS [Tên dự án],
    ISNULL(SUM(w.workHours), 0) AS [Tổng số giờ làm]
FROM tblProject p
LEFT JOIN tblWorksOn w ON p.proNum = w.proNum
GROUP BY p.proNum, p.proName
ORDER BY [Tổng số giờ làm] DESC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 32: Cho biết số lượng phòng ban làm việc theo mỗi nơi làm việc.
-- Thông tin yêu cầu: tên nơi làm việc, số lượng phòng ban
-- -------------------------------------------------------------------------------------
SELECT 
    l.locName AS [Tên nơi làm việc],
    COUNT(dl.depNum) AS [Số lượng phòng ban]
FROM tblLocation l
LEFT JOIN tblDepLocation dl ON l.locNum = dl.locNum
GROUP BY l.locNum, l.locName;
GO

-- -------------------------------------------------------------------------------------
-- Câu 33: Cho biết số lượng chỗ làm việc theo mỗi phòng ban.
-- Thông tin yêu cầu: mã phòng ban, tên phòng ban, số lượng chỗ làm việc
-- -------------------------------------------------------------------------------------
SELECT 
    d.depNum AS [Mã phòng ban],
    d.depName AS [Tên phòng ban],
    COUNT(dl.locNum) AS [Số lượng chỗ làm việc]
FROM tblDepartment d
LEFT JOIN tblDepLocation dl ON d.depNum = dl.depNum
GROUP BY d.depNum, d.depName;
GO

-- -------------------------------------------------------------------------------------
-- Câu 34: Cho biết phòng ban nào có nhiều chỗ làm việc nhất.
-- Thông tin yêu cầu: mã phòng ban, tên phòng ban, số lượng chỗ làm việc
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    d.depNum AS [Mã phòng ban],
    d.depName AS [Tên phòng ban],
    COUNT(dl.locNum) AS [Số lượng chỗ làm việc]
FROM tblDepartment d
LEFT JOIN tblDepLocation dl ON d.depNum = dl.depNum
GROUP BY d.depNum, d.depName
ORDER BY [Số lượng chỗ làm việc] DESC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 35: Cho biết phòng ban nào có ít chỗ làm việc nhất.
-- Thông tin yêu cầu: mã phòng ban, tên phòng ban, số lượng chỗ làm việc
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    d.depNum AS [Mã phòng ban],
    d.depName AS [Tên phòng ban],
    COUNT(dl.locNum) AS [Số lượng chỗ làm việc]
FROM tblDepartment d
LEFT JOIN tblDepLocation dl ON d.depNum = dl.depNum
GROUP BY d.depNum, d.depName
ORDER BY [Số lượng chỗ làm việc] ASC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 36: Cho biết địa điểm nào có nhiều phòng ban làm việc nhất.
-- Thông tin yêu cầu: tên nơi làm việc, số lượng phòng ban
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    l.locName AS [Tên nơi làm việc],
    COUNT(dl.depNum) AS [Số lượng phòng ban]
FROM tblLocation l
LEFT JOIN tblDepLocation dl ON l.locNum = dl.locNum
GROUP BY l.locNum, l.locName
ORDER BY [Số lượng phòng ban] DESC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 37: Cho biết địa điểm nào có ít phòng ban làm việc nhất.
-- Thông tin yêu cầu: tên nơi làm việc, số lượng phòng ban
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    l.locName AS [Tên nơi làm việc],
    COUNT(dl.depNum) AS [Số lượng phòng ban]
FROM tblLocation l
LEFT JOIN tblDepLocation dl ON l.locNum = dl.locNum
GROUP BY l.locNum, l.locName
ORDER BY [Số lượng phòng ban] ASC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 38: Cho biết nhân viên nào có nhiều người phụ thuộc nhất.
-- Thông tin yêu cầu: mã số, họ tên nhân viên, số lượng người phụ thuộc
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    e.empSSN AS [Mã số nhân viên],
    e.empName AS [Họ tên nhân viên],
    COUNT(d.depName) AS [Số lượng người phụ thuộc]
FROM tblEmployee e
JOIN tblDependent d ON e.empSSN = d.empSSN
GROUP BY e.empSSN, e.empName
ORDER BY [Số lượng người phụ thuộc] DESC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 39: Cho biết nhân viên nào có ít người phụ thuộc nhất.
-- Thông tin yêu cầu: mã số, họ tên nhân viên, số lượng người phụ thuộc
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    e.empSSN AS [Mã số nhân viên],
    e.empName AS [Họ tên nhân viên],
    COUNT(d.depName) AS [Số lượng người phụ thuộc]
FROM tblEmployee e
LEFT JOIN tblDependent d ON e.empSSN = d.empSSN
GROUP BY e.empSSN, e.empName
ORDER BY [Số lượng người phụ thuộc] ASC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 40: Cho biết nhân viên nào không có người phụ thuộc.
-- Thông tin yêu cầu: mã số nhân viên, họ tên nhân viên, tên phòng ban của nhân viên
-- -------------------------------------------------------------------------------------
SELECT 
    e.empSSN AS [Mã số nhân viên],
    e.empName AS [Họ tên nhân viên],
    d.depName AS [Tên phòng ban]
FROM tblEmployee e
JOIN tblDepartment d ON e.depNum = d.depNum
WHERE e.empSSN NOT IN (SELECT empSSN FROM tblDependent);
GO

-- -------------------------------------------------------------------------------------
-- Câu 41: Cho biết phòng ban nào không có người phụ thuộc.
-- Thông tin yêu cầu: mã số phòng ban, tên phòng ban
-- -------------------------------------------------------------------------------------
SELECT 
    d.depNum AS [Mã số phòng ban],
    d.depName AS [Tên phòng ban]
FROM tblDepartment d
WHERE d.depNum NOT IN (
    SELECT DISTINCT e.depNum
    FROM tblEmployee e
    JOIN tblDependent dep ON e.empSSN = dep.empSSN
);
GO

-- -------------------------------------------------------------------------------------
-- Câu 42: Cho biết những nhân viên nào chưa hề tham gia vào bất kỳ dự án nào.
-- Thông tin yêu cầu: mã số, tên nhân viên, tên phòng ban của nhân viên
-- -------------------------------------------------------------------------------------
SELECT 
    e.empSSN AS [Mã số nhân viên],
    e.empName AS [Tên nhân viên],
    d.depName AS [Tên phòng ban]
FROM tblEmployee e
JOIN tblDepartment d ON e.depNum = d.depNum
WHERE e.empSSN NOT IN (SELECT empSSN FROM tblWorksOn);
GO

-- -------------------------------------------------------------------------------------
-- Câu 43: Cho biết phòng ban không có nhân viên nào tham gia (bất kỳ) dự án.
-- Thông tin yêu cầu: mã số phòng ban, tên phòng ban
-- -------------------------------------------------------------------------------------
SELECT 
    d.depNum AS [Mã số phòng ban],
    d.depName AS [Tên phòng ban]
FROM tblDepartment d
WHERE d.depNum NOT IN (
    SELECT DISTINCT e.depNum
    FROM tblEmployee e
    JOIN tblWorksOn w ON e.empSSN = w.empSSN
);
GO

-- -------------------------------------------------------------------------------------
-- Câu 44: Cho biết phòng ban không có nhân viên nào tham gia vào dự án có tên là ProjectA.
-- Thông tin yêu cầu: mã số phòng ban, tên phòng ban
-- -------------------------------------------------------------------------------------
SELECT 
    d.depNum AS [Mã số phòng ban],
    d.depName AS [Tên phòng ban]
FROM tblDepartment d
WHERE d.depNum NOT IN (
    SELECT DISTINCT e.depNum
    FROM tblEmployee e
    JOIN tblWorksOn w ON e.empSSN = w.empSSN
    JOIN tblProject p ON w.proNum = p.proNum
    WHERE p.proName = 'ProjectA'
);
GO

-- -------------------------------------------------------------------------------------
-- Câu 45: Cho biết số lượng dự án được quản lý theo mỗi phòng ban.
-- Thông tin yêu cầu: mã phòng ban, tên phòng ban, số lượng dự án
-- -------------------------------------------------------------------------------------
SELECT 
    d.depNum AS [Mã phòng ban],
    d.depName AS [Tên phòng ban],
    COUNT(p.proNum) AS [Số lượng dự án]
FROM tblDepartment d
LEFT JOIN tblProject p ON d.depNum = p.depNum
GROUP BY d.depNum, d.depName;
GO

-- -------------------------------------------------------------------------------------
-- Câu 46: Cho biết phòng ban nào quản lý ít dự án nhất.
-- Thông tin yêu cầu: mã phòng ban, tên phòng ban, số lượng dự án
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    d.depNum AS [Mã phòng ban],
    d.depName AS [Tên phòng ban],
    COUNT(p.proNum) AS [Số lượng dự án]
FROM tblDepartment d
LEFT JOIN tblProject p ON d.depNum = p.depNum
GROUP BY d.depNum, d.depName
ORDER BY [Số lượng dự án] ASC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 47: Cho biết phòng ban nào quản lý nhiều dự án nhất.
-- Thông tin yêu cầu: mã phòng ban, tên phòng ban, số lượng dự án
-- -------------------------------------------------------------------------------------
SELECT TOP 1 WITH TIES 
    d.depNum AS [Mã phòng ban],
    d.depName AS [Tên phòng ban],
    COUNT(p.proNum) AS [Số lượng dự án]
FROM tblDepartment d
LEFT JOIN tblProject p ON d.depNum = p.depNum
GROUP BY d.depNum, d.depName
ORDER BY [Số lượng dự án] DESC;
GO

-- -------------------------------------------------------------------------------------
-- Câu 48: Cho biết những phòng ban nào có nhiều hơn 5 nhân viên đang quản lý dự án gì.
-- Thông tin yêu cầu: mã phòng ban, tên phòng ban, số lượng nhân viên của phòng ban, tên dự án quản lý
-- Ghi chú: Trong CSDL hiện tại số nhân viên tối đa của 1 phòng ban là 5 nhân viên (Phòng 1 và Phòng 2).
--          Điều kiện '>= 5' được áp dụng để hiển thị các phòng ban này. Nếu xét strictly > 5, kết quả sẽ là 0 dòng.
-- -------------------------------------------------------------------------------------
WITH DeptEmpCount AS (
    SELECT depNum, COUNT(*) AS SoLuongNhanVien
    FROM tblEmployee
    GROUP BY depNum
    HAVING COUNT(*) >= 5
)
SELECT 
    d.depNum AS [Mã phòng ban],
    d.depName AS [Tên phòng ban],
    c.SoLuongNhanVien AS [Số lượng nhân viên],
    p.proName AS [Tên dự án quản lý]
FROM tblDepartment d
JOIN DeptEmpCount c ON d.depNum = c.depNum
JOIN tblProject p ON d.depNum = p.depNum;
GO

-- -------------------------------------------------------------------------------------
-- Câu 49: Cho biết những nhân viên thuộc phòng có tên là Phòng nghiên cứu, và không có người phụ thuộc.
-- Thông tin yêu cầu: mã nhân viên, họ tên nhân viên
-- -------------------------------------------------------------------------------------
SELECT 
    e.empSSN AS [Mã nhân viên],
    e.empName AS [Họ tên nhân viên]
FROM tblEmployee e
JOIN tblDepartment d ON e.depNum = d.depNum
WHERE d.depName LIKE N'%Nghiên cứu%'
  AND e.empSSN NOT IN (SELECT empSSN FROM tblDependent);
GO

-- -------------------------------------------------------------------------------------
-- Câu 50: Cho biết tổng số giờ làm của các nhân viên, mà các nhân viên này không có người phụ thuộc.
-- Thông tin yêu cầu: mã nhân viên, họ tên nhân viên, tổng số giờ làm
-- -------------------------------------------------------------------------------------
SELECT 
    e.empSSN AS [Mã nhân viên],
    e.empName AS [Họ tên nhân viên],
    ISNULL(SUM(w.workHours), 0) AS [Tổng số giờ làm]
FROM tblEmployee e
LEFT JOIN tblWorksOn w ON e.empSSN = w.empSSN
WHERE e.empSSN NOT IN (SELECT empSSN FROM tblDependent)
GROUP BY e.empSSN, e.empName;
GO

-- -------------------------------------------------------------------------------------
-- Câu 51: Cho biết tổng số giờ làm của các nhân viên, mà các nhân viên này có nhiều hơn 3 người phụ thuộc.
-- Thông tin yêu cầu: mã nhân viên, họ tên nhân viên, số lượng người phụ thuộc, tổng số giờ làm
-- -------------------------------------------------------------------------------------
WITH EmpDep AS (
    SELECT empSSN, COUNT(*) AS SoLuongNguoiPhuThuoc
    FROM tblDependent
    GROUP BY empSSN
    HAVING COUNT(*) > 3
),
EmpHours AS (
    SELECT empSSN, SUM(workHours) AS TongSoGioLam
    FROM tblWorksOn
    GROUP BY empSSN
)
SELECT 
    e.empSSN AS [Mã nhân viên],
    e.empName AS [Họ tên nhân viên],
    ed.SoLuongNguoiPhuThuoc AS [Số lượng người phụ thuộc],
    ISNULL(eh.TongSoGioLam, 0) AS [Tổng số giờ làm]
FROM tblEmployee e
JOIN EmpDep ed ON e.empSSN = ed.empSSN
LEFT JOIN EmpHours eh ON e.empSSN = eh.empSSN;
GO

-- -------------------------------------------------------------------------------------
-- Câu 52: Cho biết tổng số giờ làm việc của các nhân viên hiện đang dưới quyền giám sát (bị quản lý bởi) của nhân viên Mai Duy An.
-- Thông tin yêu cầu: mã nhân viên, họ tên nhân viên, tổng số giờ làm
-- -------------------------------------------------------------------------------------
SELECT 
    e.empSSN AS [Mã nhân viên],
    e.empName AS [Họ tên nhân viên],
    ISNULL(SUM(w.workHours), 0) AS [Tổng số giờ làm]
FROM tblEmployee e
JOIN tblEmployee s ON e.supervisorSSN = s.empSSN
LEFT JOIN tblWorksOn w ON e.empSSN = w.empSSN
WHERE s.empName = N'Mai Duy An'
GROUP BY e.empSSN, e.empName;
GO
